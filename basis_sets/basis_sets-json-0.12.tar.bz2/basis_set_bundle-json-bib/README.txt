Basis set exchange: Basis set bundle
==========================================

Basis Set Exchange: 0.12
Created 2026-02-19 17:15:05 
Format: json
Reference format: bib

This directory contains all the basis sets in the library
in json format.

Filenames of the basis sets are in the format
{name}.{version}.{extension} where the version represents
the version of the basis set.

Filenames of the references are similar, except they
contain .ref before the final extension.

Basis set notes have a .notes extension, and family
notes have a .family_notes extension.

-------------------------------------------------
https://www.basissetexchange.org
https://github.com/MolSSI-BSE/basis_set_exchange
bse@molssi.org
-------------------------------------------------
